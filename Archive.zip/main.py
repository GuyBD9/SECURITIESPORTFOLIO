
from views.designed_view import start_repl

if __name__ == "__main__":
    start_repl()
